/**
 * PORTFOLIO CLIENT SCRIPTS - HUDHAIFA HAMID AHMED SALLAM
 */

document.addEventListener('DOMContentLoaded', () => {
  // -------------------------------------------------------------
  // 1. Language Toggle & i18n
  // -------------------------------------------------------------
  let currentLang = localStorage.getItem('portfolio_lang') || 'ar';

  const langToggleBtn = document.getElementById('langToggle');
  const langLabel = document.getElementById('langLabel');

  function setLanguage(lang) {
    currentLang = lang;
    localStorage.setItem('portfolio_lang', lang);

    const htmlEl = document.documentElement;
    const bodyEl = document.body;

    if (lang === 'ar') {
      htmlEl.lang = 'ar';
      htmlEl.dir = 'rtl';
      bodyEl.lang = 'ar';
      if (langLabel) langLabel.textContent = 'EN';
    } else {
      htmlEl.lang = 'en';
      htmlEl.dir = 'ltr';
      bodyEl.lang = 'en';
      if (langLabel) langLabel.textContent = 'عربي';
    }

    // Apply translations
    const dict = window.translations && window.translations[lang];
    if (!dict) return;

    // Translate text content
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const key = el.getAttribute('data-i18n');
      if (dict[key]) {
        el.textContent = dict[key];
      }
    });

    // Translate input placeholders
    document.querySelectorAll('[data-i18n-ph]').forEach((el) => {
      const key = el.getAttribute('data-i18n-ph');
      if (dict[key]) {
        el.setAttribute('placeholder', dict[key]);
      }
    });
  }

  if (langToggleBtn) {
    langToggleBtn.addEventListener('click', () => {
      const nextLang = currentLang === 'ar' ? 'en' : 'ar';
      setLanguage(nextLang);
    });
  }

  // Initialize Language
  setLanguage(currentLang);

  // -------------------------------------------------------------
  // 2. Theme Toggle (Dark / Light)
  // -------------------------------------------------------------
  const themeToggleBtn = document.getElementById('themeToggle');
  const themeIcon = document.getElementById('themeIcon');
  let currentTheme = localStorage.getItem('portfolio_theme') || 'dark';

  function applyTheme(theme) {
    currentTheme = theme;
    localStorage.setItem('portfolio_theme', theme);
    document.documentElement.setAttribute('data-theme', theme);

    if (themeIcon) {
      if (theme === 'light') {
        themeIcon.classList.remove('fa-sun');
        themeIcon.classList.add('fa-moon');
      } else {
        themeIcon.classList.remove('fa-moon');
        themeIcon.classList.add('fa-sun');
      }
    }
  }

  applyTheme(currentTheme);

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
      applyTheme(nextTheme);
    });
  }

  // -------------------------------------------------------------
  // 3. Navbar Scrolling & Mobile Menu
  // -------------------------------------------------------------
  const navbar = document.getElementById('navbar');
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const navLinks = document.getElementById('navLinks');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
    highlightActiveSection();
  });

  if (hamburgerBtn && navLinks) {
    hamburgerBtn.addEventListener('click', () => {
      navLinks.classList.toggle('open');
    });

    // Close menu when clicking any nav link
    navLinks.querySelectorAll('.nav-link').forEach((link) => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('open');
      });
    });
  }

  // -------------------------------------------------------------
  // 4. Highlight Active Navigation Item
  // -------------------------------------------------------------
  const sections = document.querySelectorAll('section[id]');
  const allNavLinks = document.querySelectorAll('.nav-link');

  function highlightActiveSection() {
    const scrollY = window.pageYOffset;

    sections.forEach((current) => {
      const sectionHeight = current.offsetHeight;
      const sectionTop = current.offsetTop - 120;
      const sectionId = current.getAttribute('id');

      if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
        allNavLinks.forEach((link) => {
          link.classList.remove('active');
          if (link.getAttribute('href') === `#${sectionId}`) {
            link.classList.add('active');
          }
        });
      }
    });
  }

  // -------------------------------------------------------------
  // 5. Contact Form Actions
  // -------------------------------------------------------------
  const contactForm = document.getElementById('contactForm');
  const whatsappSendBtn = document.getElementById('whatsappSendBtn');

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('senderName')?.value || '';
      const email = document.getElementById('senderEmail')?.value || '';
      const subject = document.getElementById('msgSubject')?.value || 'استفسار من موقع Portfolio';
      const body = document.getElementById('msgBody')?.value || '';

      const fullBody = `الاسم: ${name}\nالبريد: ${email}\n\nالرسالة:\n${body}`;
      const mailtoUrl = `mailto:hodifahamid@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(fullBody)}`;
      window.location.href = mailtoUrl;
    });
  }

  if (whatsappSendBtn) {
    whatsappSendBtn.addEventListener('click', () => {
      const name = document.getElementById('senderName')?.value || '';
      const subject = document.getElementById('msgSubject')?.value || '';
      const body = document.getElementById('msgBody')?.value || '';

      const text = `السلام عليكم ورحمة الله،\nأنا: ${name}\nالموضوع: ${subject}\n\n${body}`;
      const waUrl = `https://wa.me/967737010986?text=${encodeURIComponent(text)}`;
      window.open(waUrl, '_blank');
    });
  }
});

// -------------------------------------------------------------
// 6. Global Copy Function & Toast
// -------------------------------------------------------------
function copyText(text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(showToast).catch(() => fallbackCopy(text));
  } else {
    fallbackCopy(text);
  }
}

function fallbackCopy(text) {
  const tempInput = document.createElement('input');
  tempInput.value = text;
  document.body.appendChild(tempInput);
  tempInput.select();
  document.execCommand('copy');
  document.body.removeChild(tempInput);
  showToast();
}

function showToast() {
  const toast = document.getElementById('toast');
  if (!toast) return;

  const currentLang = localStorage.getItem('portfolio_lang') || 'ar';
  const msg = (window.translations && window.translations[currentLang] && window.translations[currentLang].copied_toast) || 'تم النسخ بنجاح!';
  toast.textContent = msg;

  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 2500);
}

window.copyText = copyText;
